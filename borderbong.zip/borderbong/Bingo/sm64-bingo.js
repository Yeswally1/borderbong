var bingoList = [];
// Summer Forest 1
bingoList[1] = [
  { name: "Defeat Blue & The Black Queen", types: [] },
  { name: "Defeat Dukino's Mom & The Sheriff of Lynchwood", types: [] }
];
bingoList[2] = [
  { name: "Defeat Henry & Laney White", types: [] },
  { name: "Defeat Son of Mothrakk & Knuckle Dragger", types: [] }
];
bingoList[3] = [
  { name: "Find all vault symbols in Sanctuary", types: [] },
  { name: "Find all vault symbols in Terramorphous Peak", types: [] }
];
bingoList[4] = [
  { name: "Acquire $50 million", types: [] },
  { name: "Kill a Tubby", types: [] }
];
bingoList[5] = [
  { name: "Find 2 Legendaries", types: [] },
  { name: "Find both world uniques", types: [] }
];
// 
bingoList[6] = [
  { name: "Defeat BNK3R & Savage Lee", types: [] },
  { name: "Defeat Boom Bewm & Captain Flynt", types: [] }
];
bingoList[7] = [
  { name: "Defeat Hunter Hellquist & Wilhelm", types: [] },
  { name: "Defeat Madame Von Bartlesby & King Mong", types: [] }
];
bingoList[8] = [
  { name: "Find all vault symbols in Southern Shelf", types: [] },
  { name: "Find all vault symbols in Thousand Cuts", types: [] }
];
bingoList[9] = [
  { name: "Defeat 2 Ultimate Badass Varkids", types: [] },
  { name: "Defeat OMGWTF", types: [] }
];
bingoList[10] = [
  { name: "Complete the Caustic Caverns map", types: [] },
  { name: "Complete the Sanctuary's Hole map", types: [] }
];
// 
bingoList[11] = [
  { name: "Defeat The Warrior & Scorch", types: [] },
  { name: "Defeat an Invincible", types: [] },
  { name: "Defeat a God-liath", types: [] }
];
bingoList[12] = [
  { name: "I Bet I Can Make It", types: [] },
  { name: "The Van be Damned", types: [] }
];
bingoList[13] = [
  { name: "Use 10 different travel gates", types: [] },
  { name: "Use 3 'Exit Only' Fast Travel stations", types: [] }
];
// 
bingoList[14] = [
  { name: "Defeat The Warrior & Scorch", types: [] },
  { name: "Defeat Doc Mercy & Saturn", types: [] }
];
bingoList[15] = [
  { name: "Claptrap's Birthday Bash", types: [] },
  { name: "The Bane", types: [] }
];
// 
bingoList[16] = [
  { name: "Defeat BNK3R & Savage Lee", types: [] },
  { name: "Defeat Terramorphous", types: [] }
];
bingoList[17] = [
  { name: "Find all vault symbols in The Fridge", types: [] },
  { name: "Find all vault symbols in Opportunity", types: [] }
];
bingoList[18] = [
  { name: "This Ain't My First Rodeo", types: [] },
  { name: "Complete the Opportunity map", types: [] }
];
bingoList[19] = [
  { name: "Spawn Vermivorous", types: [] },
  { name: "Find a Pearlescent", types: [] },
  { name: "Mighty Morphin'", types: [] }
];
bingoList[20] = [
  { name: "Uncle Teddy", types: [] },
  { name: "To Grandmother's House We Go", types: [] }
];
// 
bingoList[21] = [
  { name: "Defeat Pimon & Mobley", types: [] },
  { name: "Defeat Tumbaa & Gettle", types: [] }
];
bingoList[22] = [
  { name: "Buy something from a Seraph Vendor", types: [] },
  { name: "Buy 2 upgrades from Crazy Earl", types: [] },
];
bingoList[23] = [
  { name: "Complete all challenges in Three-Horns Valley", types: [] },
  { name: "Complete all challenges in Thousand Cuts", types: [] }
];
bingoList[24] = [
  { name: "Complete the Sawtooth Cauldron map", types: [] },
  { name: "Complete the Frostburn Canyon map", types: [] }
];
bingoList[25] = [
  { name: "Symbiosis", types: [] },
  { name: "Bad Hair Day", types: [] }
];

$(function() { srl.bingo(bingoList, 5); });